person.name = person.name[0].toUpperCase() + person.name[1..-1]
