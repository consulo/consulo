package org.gradle.testng;

/**
 * @author Tom Eyckmans
 */
public interface User
{
    String getFirstName();

    String getLastName();
}
