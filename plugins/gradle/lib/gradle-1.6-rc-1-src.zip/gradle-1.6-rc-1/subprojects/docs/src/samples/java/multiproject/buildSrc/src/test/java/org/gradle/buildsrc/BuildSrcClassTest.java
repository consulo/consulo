package org.gradle.buildsrc;

public class BuildSrcClassTest {
    @org.junit.Test
    public void canConstructBuildSrcClass() {
        new BuildSrcClass();
    }
}