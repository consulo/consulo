package org.gradle.apiImpl;


public class Impl {

    public void implMethod() {
        double a = 4.0 * 4;
    }

}