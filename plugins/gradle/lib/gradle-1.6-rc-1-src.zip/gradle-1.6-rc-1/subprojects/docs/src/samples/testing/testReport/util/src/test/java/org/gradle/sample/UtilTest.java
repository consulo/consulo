package org.gradle.sample;

import org.junit.Test;
import java.lang.System;

public class UtilTest {
    @Test
    public void ok() {
        System.out.println("hello from UtilTest.");
    }
}
