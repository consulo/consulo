package org.gradle

class GroovyPerson implements Person {
    def String name
}
