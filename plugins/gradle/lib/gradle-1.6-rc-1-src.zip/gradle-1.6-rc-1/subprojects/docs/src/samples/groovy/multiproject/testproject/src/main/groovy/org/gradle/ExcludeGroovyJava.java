public class ExcludeGroovyJava {

}